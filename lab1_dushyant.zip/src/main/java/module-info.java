module com.example.lab1_dushyant {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.lab1_dushyant to javafx.fxml;
    exports com.example.lab1_dushyant;
}